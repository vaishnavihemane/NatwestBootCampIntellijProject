package com.natwest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudApiGatwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudApiGatwayApplication.class, args);
	}

}
