package com.natwest.TaskRestfulWebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskRestfulWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskRestfulWebServiceApplication.class, args);
	}

}
