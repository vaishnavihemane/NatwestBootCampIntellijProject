package com.natwest.RestfulWebServiceForProduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebServiceForProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServiceForProductApplication.class, args);
	}

}
